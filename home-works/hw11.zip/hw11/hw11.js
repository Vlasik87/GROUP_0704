const buttonRed = document.querySelector(".redColor");

function clickRed() {
  buttonRed.style.backgroundColor = "red";
}
buttonRed.addEventListener("click", clickRed);

const buttonYellow = document.querySelector(".yellowColor");

function clickYellow() {
  buttonYellow.style.backgroundColor = "yellow";
}
buttonYellow.addEventListener("click", clickYellow);

const buttonGreen = document.querySelector(".greenColor");

function clickGreen() {
  buttonGreen.style.backgroundColor = "green";
}
buttonGreen.addEventListener("click", clickGreen);
