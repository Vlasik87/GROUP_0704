import { PostsPage } from "./script.js";

const root = document.querySelector(".root");
const myPostsPage = new PostsPage(root);
console.log(myPostsPage);
