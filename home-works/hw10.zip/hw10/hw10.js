var name = prompt("Enter name");
if (name === "Mila") {
  console.log("Hello Mila");
} else if (name === "Mike") {
  console.loge("Hello Dad");
} else if (name === "Helen") {
  console.log("Hello Mom");
} else {
  console.log("Hello stranger");
}

var animals = ["лев", "фламинго", "белый медведь", "удав"];
for (var i = 0; i < animals.length; i++) {
  console.log("В этом зоопарке есть " + animals[i] + ".");
}

for (var x = 3; x < 10000; x = x * 3) {
  console.log(x);
}

var count = 3;
while (count < 10000) {
  console.log(count);
  count = count * 3;
}
var animals = ["Кот", "Рыба", "Лемур", "Комодский варан"];
for (var i = 0; i < animals.length; i++) {
  console.log(animals[i] + " - прекрасное животное");
}

var alphabet = "абвгдеёжзийклмнопрстуфхцчшщъыьэюя";
var randomString = "";
while (randomString.length < 6) {
  randomString += alphabet[Math.floor(Math.random() * alphabet.length)];
}
console.log(randomString);

var input = "javascript is awesome";
var output = "";
for (var i = 0; i < input.length; i++) {
  if (input[i] === "a") {
    output += 4;
  } else if (input[i] === "e") {
    output += 3;
  } else if (input[i] === "i") {
    output += 1;
  } else if (input[i] === "o") {
    output += 0;
  } else {
    output += input[i];
  }
}
console.log(output);
