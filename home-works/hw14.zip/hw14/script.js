import { createPage } from "./form.js";

const root = document.querySelector(".root");
createPage(root);
