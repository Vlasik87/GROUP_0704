import { lighterFactory } from "./lightfactory.js";

lighterFactory(2);
