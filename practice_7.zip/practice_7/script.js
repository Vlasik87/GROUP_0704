import { Task } from "./movies.js";

const root = document.querySelector(".root");
const test = new Task(root);
console.log(test);
